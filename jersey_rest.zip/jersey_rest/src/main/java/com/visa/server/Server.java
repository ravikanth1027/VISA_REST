package com.visa.server;

import java.net.URI;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

public class Server {

	public static void main(String[] args)  throws Exception{
		String uri = "http://localhost:8080/";
		ResourceConfig cfg = new ResourceConfig();
		cfg.packages("com.visa.rest");
		HttpServer server = GrizzlyHttpServerFactory.createHttpServer( new URI(uri), cfg);
		server.start();
		System.out.println("Server Started [http://localhost:8080/]");
		System.out.println("Press any key to terminate");
		System.in.read();
		server.shutdown();
	}

}
