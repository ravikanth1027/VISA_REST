package com.visa.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name= "product")
@XmlAccessorType(XmlAccessType.FIELD)
public class Product {
	
	@XmlElement
	private int id;
	@XmlElement
	private String title;
	@XmlElement
	private double price;
	@XmlElement
	private int qty;
	
	public Product() {
	}
	
	public Product(int id, String title, double price, int qty) {
		this.id = id;
		this.title = title;
		this.price = price;
		this.qty = qty;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	
}
