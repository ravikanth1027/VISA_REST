package com.visa.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.visa.entity.Product;
import com.visa.repo.ProductRepository;

@Path("/products")
public class ProductService {

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public List<Product> getAllProducts(@QueryParam("start") @DefaultValue("0") int start) {
		System.out.println(start);
		return ProductRepository.getProducts();
	}

	@GET
	@Path("{id}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Product getProduct(@PathParam("id") int id) {
		return ProductRepository.getProduct(id);
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response addProduct(Product p) {
		ProductRepository.addProduct(p);
		return Response.status(201).entity("Product " + p.getTitle() + " added").build();
	}

	@DELETE
	@Path("{id}")
	public Response deleteProduct(@PathParam("id") int id) {
		ProductRepository.deleteProduct(id);
		return Response.status(201).entity("Product " + id + " deleted").build();
	}

	@PUT
	@Path("{id}")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response updateProduct(@PathParam("id") int id, Product p) {
		// code to interact with repo
		return Response.status(201).entity("Product " + id + " updated").build();
	}

	@POST
	@Path("/form")
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	public Response addProductUsingForm(@FormParam("id") int id,
			@FormParam("title") String title,
			@FormParam("price") double price,
			@FormParam("qty") int qty) {
		Product p = new Product(id,title,price,qty);
		ProductRepository.addProduct(p);
		return Response.status(201).entity("Product " + p.getTitle() + " added").build();
	}
}




