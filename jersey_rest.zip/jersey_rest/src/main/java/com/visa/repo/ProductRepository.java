package com.visa.repo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.visa.entity.Product;

public class ProductRepository {
	
	private static List<Product> products = new ArrayList<Product>();
	
	static {
		products.add(new Product(1,"Dell Laptop",45000.00,100));
		products.add(new Product(2,"iPhone 6",65000.00,700));
		products.add(new Product(3,"Moto Force",33000.00,100));
		products.add(new Product(4,"Logitech Mouse",500.00,900));
	}
	
	public static List<Product> getProducts() {
		return products;
	}
	public static void addProduct(Product p) {
		products.add(p);
	}
	
	public static Product getProduct(int id) {
		Product p = null;
		Iterator<Product> iter = products.iterator();
		while(iter.hasNext()) {
			Product prd = iter.next();
			if(prd.getId() == id) {
				p = prd; 
			}
		}
		return p;
	}
	
	public static void deleteProduct(int id) {
		Iterator<Product> iter = products.iterator();
		while(iter.hasNext()) {
			if(iter.next().getId() == id) {
				iter.remove();
			}
		}
	}
}










